/**
 * velocity_controller.cpp
 * -----------------------
 * ROS2 C++ node: subscribes to vision commands and publishes
 * geometry_msgs/Twist to the robot's /cmd_vel topic.
 *
 * Subscribes
 *   /vision/steering_cmd  (std_msgs/Float32)  – normalised [-1, 1]
 *   /vision/obstacle_dist (std_msgs/Float32)  – metres to nearest obstacle
 *   /odom                 (nav_msgs/Odometry) – for velocity feedback
 *
 * Publishes
 *   /cmd_vel (geometry_msgs/Twist)
 */

#include <chrono>
#include <algorithm>
#include <cmath>

#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "nav_msgs/msg/odometry.hpp"
#include "std_msgs/msg/float32.hpp"

using namespace std::chrono_literals;
using std::placeholders::_1;

// ── Constants ──────────────────────────────────────────────────────────────
static constexpr double BASE_SPEED       = 0.25;   // m/s cruise speed
static constexpr double MAX_ANGULAR      = 1.2;    // rad/s
static constexpr double STOP_DIST        = 0.40;   // m – emergency stop
static constexpr double SLOW_DIST        = 1.00;   // m – start slowing down
static constexpr double CTRL_PERIOD_MS   = 50;     // 20 Hz

class VelocityController : public rclcpp::Node
{
public:
  VelocityController() : Node("velocity_controller")
  {
    // Parameters
    this->declare_parameter<double>("base_speed",  BASE_SPEED);
    this->declare_parameter<double>("max_angular", MAX_ANGULAR);
    this->declare_parameter<double>("stop_dist",   STOP_DIST);
    this->declare_parameter<double>("slow_dist",   SLOW_DIST);

    base_speed_  = this->get_parameter("base_speed").as_double();
    max_angular_ = this->get_parameter("max_angular").as_double();
    stop_dist_   = this->get_parameter("stop_dist").as_double();
    slow_dist_   = this->get_parameter("slow_dist").as_double();

    // Subscribers
    sub_steering_ = this->create_subscription<std_msgs::msg::Float32>(
      "/vision/steering_cmd", 10,
      std::bind(&VelocityController::steering_cb, this, _1));

    sub_obstacle_ = this->create_subscription<std_msgs::msg::Float32>(
      "/vision/obstacle_dist", 10,
      std::bind(&VelocityController::obstacle_cb, this, _1));

    sub_odom_ = this->create_subscription<nav_msgs::msg::Odometry>(
      "/odom", 10,
      std::bind(&VelocityController::odom_cb, this, _1));

    // Publisher
    pub_cmd_ = this->create_publisher<geometry_msgs::msg::Twist>("/cmd_vel", 10);

    // Control loop timer
    timer_ = this->create_wall_timer(
      std::chrono::milliseconds(CTRL_PERIOD_MS),
      std::bind(&VelocityController::control_loop, this));

    RCLCPP_INFO(this->get_logger(),
      "VelocityController ready — base_speed=%.2f m/s, stop_dist=%.2f m",
      base_speed_, stop_dist_);
  }

private:
  // ── Callbacks ─────────────────────────────────────────────────────────
  void steering_cb(const std_msgs::msg::Float32::SharedPtr msg)
  {
    // Clamp incoming steering to [-1, 1]
    steering_ = std::clamp(static_cast<double>(msg->data), -1.0, 1.0);
  }

  void obstacle_cb(const std_msgs::msg::Float32::SharedPtr msg)
  {
    obstacle_dist_ = static_cast<double>(msg->data);
  }

  void odom_cb(const nav_msgs::msg::Odometry::SharedPtr msg)
  {
    current_linear_vel_ = msg->twist.twist.linear.x;
  }

  // ── Control loop (20 Hz) ──────────────────────────────────────────────
  void control_loop()
  {
    geometry_msgs::msg::Twist cmd;

    if (obstacle_dist_ < stop_dist_) {
      // Emergency stop
      cmd.linear.x  = 0.0;
      cmd.angular.z = 0.0;
      RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 1000,
        "OBSTACLE — %.2f m — STOPPED", obstacle_dist_);
    } else {
      // Speed scaling based on proximity
      double speed_scale = 1.0;
      if (obstacle_dist_ < slow_dist_) {
        speed_scale = (obstacle_dist_ - stop_dist_) / (slow_dist_ - stop_dist_);
        speed_scale = std::clamp(speed_scale, 0.0, 1.0);
      }

      cmd.linear.x  = base_speed_ * speed_scale;
      cmd.angular.z = steering_ * max_angular_;
    }

    pub_cmd_->publish(cmd);
  }

  // ── Members ───────────────────────────────────────────────────────────
  rclcpp::Subscription<std_msgs::msg::Float32>::SharedPtr  sub_steering_;
  rclcpp::Subscription<std_msgs::msg::Float32>::SharedPtr  sub_obstacle_;
  rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr sub_odom_;
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr  pub_cmd_;
  rclcpp::TimerBase::SharedPtr                             timer_;

  double steering_          = 0.0;
  double obstacle_dist_     = 9999.0;
  double current_linear_vel_= 0.0;

  double base_speed_;
  double max_angular_;
  double stop_dist_;
  double slow_dist_;
};

// ── main ──────────────────────────────────────────────────────────────────
int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<VelocityController>());
  rclcpp::shutdown();
  return 0;
}
