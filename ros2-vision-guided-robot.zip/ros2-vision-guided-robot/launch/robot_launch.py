"""
robot_launch.py
---------------
Launch all nodes for the vision-guided robot.

Usage:
    ros2 launch vision_guided_robot robot_launch.py
    ros2 launch vision_guided_robot robot_launch.py use_depth:=false
"""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    use_depth_arg = DeclareLaunchArgument(
        "use_depth", default_value="true",
        description="Use depth camera (true) or LaserScan (false)"
    )
    debug_arg = DeclareLaunchArgument(
        "debug", default_value="true",
        description="Publish debug images from vision node"
    )

    vision_node = Node(
        package="vision_guided_robot",
        executable="vision_node.py",
        name="vision_node",
        output="screen",
        parameters=[{
            "debug": LaunchConfiguration("debug"),
            "roi_top_frac": 0.55,
            "canny_lo": 50,
            "canny_hi": 150,
        }],
    )

    obstacle_node = Node(
        package="vision_guided_robot",
        executable="obstacle_node.py",
        name="obstacle_node",
        output="screen",
        parameters=[{
            "use_depth": LaunchConfiguration("use_depth"),
            "max_range": 5.0,
        }],
    )

    velocity_controller = Node(
        package="vision_guided_robot",
        executable="velocity_controller",
        name="velocity_controller",
        output="screen",
        parameters=[{
            "base_speed": 0.25,
            "max_angular": 1.2,
            "stop_dist": 0.40,
            "slow_dist": 1.00,
        }],
    )

    return LaunchDescription([
        use_depth_arg,
        debug_arg,
        vision_node,
        obstacle_node,
        velocity_controller,
    ])
