#!/usr/bin/env python3
"""
obstacle_node.py
----------------
ROS2 Python node: estimates the distance to the nearest obstacle from a
depth image or a 2-D LaserScan.

Subscribes (one of):
    /camera/depth/image_raw  (sensor_msgs/Image, 32FC1 metres)
    /scan                    (sensor_msgs/LaserScan)

Publishes:
    /vision/obstacle_dist (std_msgs/Float32)  – metres
"""

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image, LaserScan
from std_msgs.msg import Float32
from cv_bridge import CvBridge

import numpy as np


class ObstacleNode(Node):

    def __init__(self):
        super().__init__("obstacle_node")

        self.declare_parameter("use_depth",     True)   # False = use LaserScan
        self.declare_parameter("roi_frac",      0.40)   # centre fraction of depth img
        self.declare_parameter("max_range",     5.00)   # metres

        self.use_depth  = self.get_parameter("use_depth").value
        self.roi_frac   = self.get_parameter("roi_frac").value
        self.max_range  = self.get_parameter("max_range").value
        self.bridge     = CvBridge()

        self.pub_dist = self.create_publisher(Float32, "/vision/obstacle_dist", 10)

        if self.use_depth:
            self.sub = self.create_subscription(
                Image, "/camera/depth/image_raw", self.depth_cb, 10
            )
            self.get_logger().info("ObstacleNode: using depth camera")
        else:
            self.sub = self.create_subscription(
                LaserScan, "/scan", self.scan_cb, 10
            )
            self.get_logger().info("ObstacleNode: using LaserScan")

    # ------------------------------------------------------------------
    def depth_cb(self, msg: Image):
        depth = self.bridge.imgmsg_to_cv2(msg, desired_encoding="32FC1")
        h, w  = depth.shape

        # Central ROI
        cy1 = int(h * (0.5 - self.roi_frac / 2))
        cy2 = int(h * (0.5 + self.roi_frac / 2))
        cx1 = int(w * (0.5 - self.roi_frac / 2))
        cx2 = int(w * (0.5 + self.roi_frac / 2))
        roi = depth[cy1:cy2, cx1:cx2]

        valid = roi[(roi > 0.1) & (roi < self.max_range)]
        dist  = float(np.min(valid)) if len(valid) else self.max_range

        self.pub_dist.publish(Float32(data=dist))

    def scan_cb(self, msg: LaserScan):
        ranges = np.array(msg.ranges)
        valid  = ranges[(ranges > msg.range_min) & (ranges < self.max_range)]
        dist   = float(np.min(valid)) if len(valid) else self.max_range
        self.pub_dist.publish(Float32(data=dist))


# ------------------------------------------------------------------
def main(args=None):
    rclpy.init(args=args)
    node = ObstacleNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
