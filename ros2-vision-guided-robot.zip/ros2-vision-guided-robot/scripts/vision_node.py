#!/usr/bin/env python3
"""
vision_node.py
--------------
ROS2 Python node: processes camera frames with OpenCV to detect lane
centre and publish a normalised steering command.

Subscribes  : /camera/image_raw  (sensor_msgs/Image)
Publishes   : /vision/steering_cmd (std_msgs/Float32)
              /vision/debug_image  (sensor_msgs/Image)
"""

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import Float32
from cv_bridge import CvBridge

import cv2
import numpy as np


class VisionNode(Node):
    """
    Lane-centre detection via colour thresholding + moment-based steering.

    Algorithm
    ---------
    1. Convert BGR → HSV and threshold for road/lane colour
    2. Apply Gaussian blur + Canny edges in ROI (lower 40% of frame)
    3. Hough line detection → average left / right lane candidates
    4. Compute lane-centre offset from image centre
    5. Normalise to [-1, 1] and publish
    """

    def __init__(self):
        super().__init__("vision_node")

        # Parameters
        self.declare_parameter("roi_top_frac", 0.55)   # upper crop boundary
        self.declare_parameter("canny_lo",     50)
        self.declare_parameter("canny_hi",     150)
        self.declare_parameter("hough_thresh", 40)
        self.declare_parameter("debug",        True)

        self.roi_frac    = self.get_parameter("roi_top_frac").value
        self.canny_lo    = self.get_parameter("canny_lo").value
        self.canny_hi    = self.get_parameter("canny_hi").value
        self.hough_thr   = self.get_parameter("hough_thresh").value
        self.debug       = self.get_parameter("debug").value

        self.bridge = CvBridge()

        # Subscribers / Publishers
        self.sub_img = self.create_subscription(
            Image, "/camera/image_raw", self.image_cb, 10
        )
        self.pub_steer = self.create_publisher(Float32, "/vision/steering_cmd", 10)
        if self.debug:
            self.pub_dbg = self.create_publisher(Image, "/vision/debug_image", 10)

        self.get_logger().info("VisionNode ready — waiting for frames …")

    # ------------------------------------------------------------------
    def image_cb(self, msg: Image):
        frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding="bgr8")
        h, w  = frame.shape[:2]

        # Region of interest
        roi_y = int(h * self.roi_frac)
        roi   = frame[roi_y:h, :]

        # Edge detection
        gray  = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
        blur  = cv2.GaussianBlur(gray, (5, 5), 0)
        edges = cv2.Canny(blur, self.canny_lo, self.canny_hi)

        # Hough lines
        lines = cv2.HoughLinesP(
            edges,
            rho=1, theta=np.pi / 180,
            threshold=self.hough_thr,
            minLineLength=40,
            maxLineGap=20,
        )

        steering = self._compute_steering(lines, w)
        self.pub_steer.publish(Float32(data=float(steering)))

        if self.debug:
            dbg = frame.copy()
            cv2.line(dbg, (w // 2, roi_y), (w // 2, h), (0, 255, 0), 1)
            if lines is not None:
                for line in lines:
                    x1, y1, x2, y2 = line[0]
                    cv2.line(dbg, (x1, y1 + roi_y), (x2, y2 + roi_y),
                             (0, 120, 255), 2)
            cv2.putText(
                dbg, f"Steer: {steering:+.3f}", (8, 28),
                cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 0), 2,
            )
            self.pub_dbg.publish(
                self.bridge.cv2_to_imgmsg(dbg, encoding="bgr8")
            )

    # ------------------------------------------------------------------
    def _compute_steering(
        self, lines, frame_width: int
    ) -> float:
        """
        Average x-intercept of detected lines → normalised offset.
        Returns 0.0 if no lines found.
        """
        if lines is None:
            return 0.0

        xs = []
        for line in lines:
            x1, _, x2, _ = line[0]
            xs.append((x1 + x2) / 2.0)

        if not xs:
            return 0.0

        centre_x  = np.mean(xs)
        offset    = centre_x - frame_width / 2.0
        normalised = offset / (frame_width / 2.0)
        return float(np.clip(normalised, -1.0, 1.0))


# ------------------------------------------------------------------
def main(args=None):
    rclpy.init(args=args)
    node = VisionNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
